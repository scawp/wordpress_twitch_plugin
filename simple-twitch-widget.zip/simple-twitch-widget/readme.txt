=== My Twitch ===
Contributors: scawp
Tags: twitch, streaming
Requires at least: 5.7.2
Tested up to: 5.7.2
Stable tag: 0.0.1
License: MIT

Twitch sidebar

== Description ==
A Simple Twitch Sidebar Widget