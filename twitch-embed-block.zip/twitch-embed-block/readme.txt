=== Twitch Embed Bock ===
Contributors: scawp
Tags: twitch, streaming
Requires at least: 5.7.2
Tested up to: 5.7.2
Stable tag: 0.0.1
License: MIT

Twitch Embed Block

== Description ==
A Twitch Embed Block